<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Http\Client\ConnectionException;
use App\Models\LedgerEntry;     
use App\Models\ChartOfAccount;  

class AccountCodeController extends Controller
{
    public function showDocument($filename)
    {
        if (!Storage::disk('private')->exists('uploads/' . $filename)) {
            abort(404);
        }
        return response()->file(storage_path('app/private/uploads/' . $filename));
    }

    public function index($step = 1)
    {
        $step = in_array($step, [1, 2, 3]) ? $step : 1;

        // Validasi Step
        if ($step == 2 && !session()->has('file_to_process')) {
            return redirect()->route('account-code-recommender.show', ['step' => 1]);
        }
        if ($step == 3 && !session()->has('prediction_result')) {
            return redirect()->route('account-code-recommender.show', ['step' => 1]);
        }

        $result = session('prediction_result', null);
        $filePath = session('file_to_process', null);
        $imageUrl = null;

        if ($filePath) {
            $filename = basename($filePath);
            $imageUrl = route('document.show', ['filename' => $filename]);
        }

        // --- [LOGIKA KODE 1: Master Data ChartOfAccount] ---
        $accounts = ChartOfAccount::orderBy('code')
                    ->get()
                    ->groupBy('category'); 
        
        $orderedCategories = ['Aset', 'Kewajiban', 'Ekuitas', 'Pendapatan', 'Beban'];
        
        $sortedAccounts = $accounts->sortBy(function ($item, $key) use ($orderedCategories) {
            return array_search($key, $orderedCategories);
        });

        return view('dashboard.account-code-recommender', [
            'step' => (int) $step,
            'result' => $result, 
            'image_url' => $imageUrl,
            'groupedAccounts' => $sortedAccounts 
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'document' => 'required|image|mimes:jpeg,png,jpg|max:10240',
        ], [
            'document.required' => 'Pilih file terlebih dahulu.',
            'document.image' => 'File harus berupa gambar.',
            'document.mimes' => 'Format salah. Gunakan JPG atau PNG.',
            'document.max' => 'Ukuran terlalu besar (Maks 10MB).',
        ]);

        if ($request->hasFile('document')) {
            $path = $request->file('document')->store('uploads', 'private');
            session(['file_to_process' => $path]);
            // redirect ke Step 2
            return redirect()->route('account-code-recommender.show', ['step' => 2])
                ->with('success', 'File berhasil di-upload.'); 
        }

        return redirect()->route('account-code-recommender.show', ['step' => 1])
            ->with('error', 'Gagal, tidak ada file yang dipilih.');
    }

    public function processImage(Request $request)
    {
        // 1. Set Time Limit Unlimited agar PHP tidak kill process saat menunggu AI
        set_time_limit(0); 
        
        $path = session('file_to_process');
        
        if (!$path) return response()->json(['status' => 'error', 'message' => 'File tidak ditemukan di sesi.'], 400);

        $fullPath = Storage::disk('private')->path($path);
        
        try {
            // 2. Request ke Flask dengan Timeout Setting yang Tepat
            $response = Http::asMultipart()
                ->timeout(120)       
                ->connectTimeout(120) 
                ->attach('file', file_get_contents($fullPath), basename($path))
                ->post('http://127.0.0.1:5000/analyze');

            // 3. Cek Status HTTP dari Flask
            if (!$response->successful()) {
                $errorMessage = $response->json('error', 'Server AI mengembalikan error.');
                return response()->json(['status' => 'error', 'message' => $errorMessage], 502);
            }

            $data = $response->json();

            // 4. Validasi Struktur Data
            if (isset($data['llm']) && is_array($data['llm'])) {
                session(['prediction_result' => $data['llm']]);
                return response()->json(['status' => 'success']);
            } else {
                return response()->json(['status' => 'error', 'message' => 'Format respon AI tidak sesuai.'], 500);
            }

        } catch (ConnectionException $e) {
            // 5. [PENTING] Menangkap Error Timeout / Koneksi Mati
            return response()->json([
                'status' => 'error', 
                'message' => 'Koneksi ke AI Timeout. Server mungkin sibuk atau mati. Coba lagi nanti.'
            ], 504);

        } catch (\Exception $e) {
            // 6. Error Umum Lainnya
            return response()->json(['status' => 'error', 'message' => $e->getMessage()], 500);
        }
    }

    public function save(Request $request)
    {
        try {
            // [LOGIKA KODE 1: Generate Nomor Transaksi Berdasarkan Jenis Bukti]
            $prefix = $request->input('jenis_bukti', 'BKK'); 
            $tanggal = $request->input('tanggal');
            $periode = \Carbon\Carbon::parse($tanggal)->format('ym'); 
            
            $count = LedgerEntry::where('transaction_code', 'like', "$prefix-$periode-%")
                        ->distinct('transaction_group_id')
                        ->count();
            $noUrut = str_pad($count + 1, 3, '0', STR_PAD_LEFT);
            $trxCode = "$prefix-$periode-$noUrut";
            
            $trxGroupId = (string) Str::uuid();
            $nominal = $request->input('nominal_total');
            $desc = $request->input('deskripsi');
            $filePath = session('file_to_process');

            // Ambil Nama Akun dari DB Master (Fitur Kode 1)
            $debitCode = $request->input('selected_account');
            $creditCode = $request->input('payment_account_code');

            $debitAcc = ChartOfAccount::where('code', $debitCode)->first();
            $creditAcc = ChartOfAccount::where('code', $creditCode)->first();

            // Simpan Sisi DEBIT
            LedgerEntry::create([
                'transaction_group_id' => $trxGroupId,
                'transaction_code' => $trxCode,
                'date' => $tanggal,
                'account_code' => $debitCode,
                'account_name' => $debitAcc ? $debitAcc->name : 'Unknown', 
                'debit' => $nominal,
                'credit' => 0,
                'description' => $desc,
                'receipt_image_path' => $filePath,
            ]);

            // Simpan Sisi KREDIT
            LedgerEntry::create([
                'transaction_group_id' => $trxGroupId,
                'transaction_code' => $trxCode,
                'date' => $tanggal,
                'account_code' => $creditCode,
                'account_name' => $creditAcc ? $creditAcc->name : 'Unknown', 
                'debit' => 0,
                'credit' => $nominal,
                'description' => $desc,
                'receipt_image_path' => $filePath,
            ]);

            session()->forget(['prediction_result', 'file_to_process']);
            
            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage()], 500);
        }
    }
}