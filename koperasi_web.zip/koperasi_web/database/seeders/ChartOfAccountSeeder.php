<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ChartOfAccountSeeder extends Seeder
{
    public function run(): void
    {
        // Kosongkan tabel lama
        DB::table('chart_of_accounts')->truncate();

        $accounts = [
            // ==========================================
            // 1. HARTA (ASET) - Saldo Normal: DEBIT
            // ==========================================
            
            // 1.1 Harta Lancar
            ['code' => '111', 'name' => 'Kas', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '112', 'name' => 'Surat-surat Berharga', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '113', 'name' => 'Piutang Usaha', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '114', 'name' => 'Wesel Tagih', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '115', 'name' => 'Persekot / Uang Muka', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '116', 'name' => 'Pendapatan YMHD', 'category' => 'Aset', 'normal_balance' => 'debit'], // Yang Masih Harus Diterima
            ['code' => '117', 'name' => 'Persediaan Barang Dagang', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '118', 'name' => 'Perlengkapan Toko', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '119', 'name' => 'Perlengkapan Kantor', 'category' => 'Aset', 'normal_balance' => 'debit'],

            // 1.2 Investasi
            ['code' => '121', 'name' => 'Investasi Uang Tunai', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '122', 'name' => 'Investasi Surat Berharga', 'category' => 'Aset', 'normal_balance' => 'debit'],

            // 1.3 Harta Tetap Berwujud
            ['code' => '131', 'name' => 'Peralatan Toko', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '132', 'name' => 'Peralatan Kantor', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '133', 'name' => 'Kendaraan', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '134', 'name' => 'Mesin', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '135', 'name' => 'Bangunan', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '136', 'name' => 'Tanah', 'category' => 'Aset', 'normal_balance' => 'debit'],

            // 1.4 Harta Tetap Tak Berwujud
            ['code' => '141', 'name' => 'Copyright', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '142', 'name' => 'Hak Paten', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '143', 'name' => 'Hak Merek', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '144', 'name' => 'Hak Cipta', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '145', 'name' => 'Goodwill', 'category' => 'Aset', 'normal_balance' => 'debit'],
            ['code' => '146', 'name' => 'Waralaba (Franchise)', 'category' => 'Aset', 'normal_balance' => 'debit'],

            // 1.5 Harta Lain-lain
            ['code' => '151', 'name' => 'Harta Rusak / Lain-lain', 'category' => 'Aset', 'normal_balance' => 'debit'],


            // ==========================================
            // 2. UTANG (HUTANG) - Saldo Normal: KREDIT
            // ==========================================

            // 2.1 Utang Jangka Pendek
            ['code' => '211', 'name' => 'Utang Usaha', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '212', 'name' => 'Utang Bunga', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '213', 'name' => 'Utang Gaji', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '214', 'name' => 'Utang Sewa', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '215', 'name' => 'Beban Yang Harus Dibayar', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '216', 'name' => 'Pendapatan Diterima Dimuka', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '217', 'name' => 'Utang Listrik', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '218', 'name' => 'Utang Bayar (Notes Payable)', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],

            // 2.2 Utang Jangka Panjang
            ['code' => '221', 'name' => 'Utang Bank', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '222', 'name' => 'Utang Hipotik', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '223', 'name' => 'Utang KIK', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '224', 'name' => 'Utang KUK', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '225', 'name' => 'Utang KUM', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],
            ['code' => '226', 'name' => 'Utang KRIDA', 'category' => 'Kewajiban', 'normal_balance' => 'credit'],


            // ==========================================
            // 3. MODAL (EKUITAS) - Saldo Normal: KREDIT
            // ==========================================

            // 3.1 Modal Sendiri
            ['code' => '311', 'name' => 'Modal Uang Tunai', 'category' => 'Ekuitas', 'normal_balance' => 'credit'],
            ['code' => '312', 'name' => 'Modal Surat Berharga', 'category' => 'Ekuitas', 'normal_balance' => 'credit'],

            // 3.2 Modal Pinjaman
            ['code' => '321', 'name' => 'Modal Pinjaman Tunai', 'category' => 'Ekuitas', 'normal_balance' => 'credit'],
            ['code' => '322', 'name' => 'Modal Pinjaman Surat Berharga', 'category' => 'Ekuitas', 'normal_balance' => 'credit'],

            // 3.3 Modal Saham
            ['code' => '331', 'name' => 'Modal Saham Biasa', 'category' => 'Ekuitas', 'normal_balance' => 'credit'],
            ['code' => '332', 'name' => 'Modal Saham Istimewa', 'category' => 'Ekuitas', 'normal_balance' => 'credit'],


            // ==========================================
            // 4. PENDAPATAN - Saldo Normal: KREDIT
            // ==========================================

            // 4.1 Pendapatan Usaha
            ['code' => '411', 'name' => 'Pendapatan Jasa Salon', 'category' => 'Pendapatan', 'normal_balance' => 'credit'],
            ['code' => '412', 'name' => 'Pendapatan Jasa Angkutan', 'category' => 'Pendapatan', 'normal_balance' => 'credit'],
            ['code' => '413', 'name' => 'Pendapatan Jasa Bengkel', 'category' => 'Pendapatan', 'normal_balance' => 'credit'],
            ['code' => '414', 'name' => 'Pendapatan Jasa Servis', 'category' => 'Pendapatan', 'normal_balance' => 'credit'],
            ['code' => '415', 'name' => 'Pendapatan Jasa Tailor', 'category' => 'Pendapatan', 'normal_balance' => 'credit'],
            ['code' => '416', 'name' => 'Pendapatan Jasa Laundry', 'category' => 'Pendapatan', 'normal_balance' => 'credit'],
            ['code' => '417', 'name' => 'Pendapatan Jasa Komisi', 'category' => 'Pendapatan', 'normal_balance' => 'credit'],

            // 4.2 Pendapatan Luar Usaha
            ['code' => '421', 'name' => 'Pendapatan Bunga', 'category' => 'Pendapatan', 'normal_balance' => 'credit'],
            ['code' => '422', 'name' => 'Laba Penjualan Harta', 'category' => 'Pendapatan', 'normal_balance' => 'credit'],


            // ==========================================
            // 5. BEBAN - Saldo Normal: DEBIT
            // ==========================================

            // 5.1 Beban Usaha
            ['code' => '511', 'name' => 'Beban Gaji', 'category' => 'Beban', 'normal_balance' => 'debit'],
            ['code' => '512', 'name' => 'Beban Sewa', 'category' => 'Beban', 'normal_balance' => 'debit'],
            ['code' => '513', 'name' => 'Beban Listrik', 'category' => 'Beban', 'normal_balance' => 'debit'],
            ['code' => '514', 'name' => 'Beban Asuransi', 'category' => 'Beban', 'normal_balance' => 'debit'],
            ['code' => '515', 'name' => 'Beban Perlengkapan', 'category' => 'Beban', 'normal_balance' => 'debit'],
            ['code' => '516', 'name' => 'Beban Penyusutan Harta Tetap', 'category' => 'Beban', 'normal_balance' => 'debit'],
            ['code' => '517', 'name' => 'Beban Rupa-rupa', 'category' => 'Beban', 'normal_balance' => 'debit'],

            // 5.2 Beban Luar Usaha
            ['code' => '521', 'name' => 'Beban Bunga', 'category' => 'Beban', 'normal_balance' => 'debit'],
            ['code' => '522', 'name' => 'Beban Penjualan Harta', 'category' => 'Beban', 'normal_balance' => 'debit'],
            ['code' => '523', 'name' => 'Kerugian Kecurian Uang/Barang', 'category' => 'Beban', 'normal_balance' => 'debit'],
        ];

        DB::table('chart_of_accounts')->insert($accounts);
    }
}