

<?php $__env->startSection('page_title', 'Jurnal Umum'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <form action="<?php echo e(route('ledger')); ?>" method="GET">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="d-flex align-items-center gap-2">
                <input type="text" class="form-select" id="dateRangeFilter" name="date_range" 
                    value="<?php echo e($dateRange ?? ''); ?>" placeholder="Pilih Rentang Periode" style="width: 240px;">

                <button type="submit" class="btn btn-outline-secondary">
                    <i class="bi bi-funnel me-1"></i> Filter
                </button>
            </div>
            <div class="d-flex gap-2">
                <?php
                    $isDataEmpty = $paginator->isEmpty();
                ?>
                <a href="<?php echo e($isDataEmpty ? '#' : route('ledger.export', request()->query())); ?>" 
                class="btn btn-primary <?php echo e($isDataEmpty ? 'disabled' : ''); ?>"
                <?php if($isDataEmpty): ?> 
                    onclick="event.preventDefault(); alert('Tidak ada data untuk diekspor.');" 
                <?php endif; ?>>
                    <i class="bi bi-download me-1"></i> Unduh File CSV
                </a>
            </div>
        </div>
    </form>

    <div class="table-responsive bg-white shadow-sm rounded">
        <table class="table align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Tanggal</th>
                    <th style="white-space: nowrap;">Kode Transaksi</th>
                    <th style="width: 30%;">Keterangan</th> 
                    <th>Akun</th>
                    <th>Debit (Rp)</th>
                    <th>Kredit (Rp)</th>
                    <th>Detail</th> 
                </tr>
            </thead>
            
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_id => $entries_in_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                    <?php
                        $debit_entry = $entries_in_group->where('debit', '>', 0)->first();
                        $credit_entry = $entries_in_group->where('credit', '>', 0)->first();
                        $main_entry = $debit_entry ?? $entries_in_group->first();
                    ?>

                    <tr class="transaction-row-top">
                        <td rowspan="2" class="transaction-group-cell">
                            <?php echo e(\Carbon\Carbon::parse($main_entry->date)->format('d-M-Y')); ?>

                        </td>
                        <td rowspan="2" class="transaction-group-cell">
                            <?php echo e($main_entry->transaction_code); ?>

                        </td>
                        <td rowspan="2" class="transaction-group-cell">
                            <?php echo e($main_entry->description); ?>

                        </td>
                        <td>
                            <?php if($debit_entry): ?>
                                <?php echo e($debit_entry->account_code); ?> - <?php echo e($debit_entry->account_name); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($debit_entry ? number_format($debit_entry->debit, 2) : '-'); ?></td>
                        <td>-</td>
                        <td rowspan="2" class="transaction-group-cell text-center">
                            <div class="btn-group btn-group-sm" role="group">
                                <button type="button" class="btn btn-outline-info" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#proofModal-<?php echo e($main_entry->id); ?>">
                                    Lihat Bukti
                                </button>
                                <button type="button" class="btn btn-outline-secondary" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#itemsModal-<?php echo e($main_entry->id); ?>">
                                    Lihat Item
                                </button>
                            </div>
                        </td>
                    </tr>
                    
                    <tr class="transaction-row-bottom">
                        <td>
                            <?php if($credit_entry): ?>
                                <?php echo e($credit_entry->account_code); ?> - <?php echo e($credit_entry->account_name); ?>

                            <?php endif; ?>
                        </td>
                        <td>-</td>
                        <td><?php echo e($credit_entry ? number_format($credit_entry->credit, 2) : '-'); ?></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            Tidak ada transaksi ditemukan.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-between align-items-center mt-3">
        <div class="small text-muted">
            Showing <?php echo e($paginator->firstItem()); ?> to <?php echo e($paginator->lastItem()); ?> of <?php echo e($paginator->total()); ?> transactions
        </div>
        <?php echo e($paginator->appends(request()->query())->links()); ?>

    </div>
</div>

<?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_id => $entries_in_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $debit_entry = $entries_in_group->where('debit', '>', 0)->first();
        $main_entry = $debit_entry ?? $entries_in_group->first();
    ?>

    <div class="modal fade" id="proofModal-<?php echo e($main_entry->id); ?>" tabindex="-1" aria-labelledby="proofModalLabel-<?php echo e($main_entry->id); ?>" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="proofModalLabel-<?php echo e($main_entry->id); ?>">Bukti Transaksi</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <img src="<?php echo e(route('document.show', ['filename' => basename($main_entry->receipt_image_path)])); ?>" alt="Receipt" class="img-fluid w-100">
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade" id="itemsModal-<?php echo e($main_entry->id); ?>" tabindex="-1" aria-labelledby="itemsModalLabel-<?php echo e($main_entry->id); ?>" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="itemsModalLabel-<?php echo e($main_entry->id); ?>">Detail Item</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body"> 
            
            <?php if($debit_entry && $debit_entry->items->count() > 0): ?>
              <table class="table">
                <thead>
                    <tr><th>Nama Item</th><th>Harga</th><th>Kuantitas</th><th>Subtotal</th></tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $debit_entry->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->item_name); ?></td>
                            <td><?php echo e(number_format($item->price, 2)); ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td><?php echo e(number_format($item->price * $item->quantity, 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            <?php else: ?>
              <div class="alert alert-info text-center" role="alert">
                Tidak ada item untuk transaksi ini.
              </div>
            <?php endif; ?>

          </div>
        </div>
      </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<style>
    .table > :not(caption) > * > * {
        border-bottom-width: 0 !important;
    }
    .table th, .table td {
        vertical-align: middle;
    }
    .table thead th {
        font-weight: 600;
        border-bottom-width: 2px !important; 
    }
    .pagination { margin-bottom: 0; }
    .table > tbody > tr,
    .table > tbody > tr > td {
        border: none !important;
    }
    .table tbody tr td {
        border-top: none !important;
        border-bottom: none !important;
    }
    .transaction-group-cell {
        vertical-align: top !important;
        padding-top: 1rem !important;
    }
    .transaction-row-top > td {
        padding-bottom: 0.25rem;
    }
    .transaction-row-bottom > td {
        padding-top: 0.25rem;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    // Inisialisasi flatpickr dalam mode "range"
    flatpickr("#dateRangeFilter", {
        mode: "range",
        dateFormat: "Y-m-d", // Format yang akan dikirim ke Laravel
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\koperasi\koperasi_web\resources\views/dashboard/ledger.blade.php ENDPATH**/ ?>