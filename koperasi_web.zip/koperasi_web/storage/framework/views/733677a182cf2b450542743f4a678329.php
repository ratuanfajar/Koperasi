

<?php $__env->startSection('content'); ?>
<div class="login-card">
    
    <div class="logo-icon-wrapper">
        <i class="bi bi-box-arrow-in-right fs-4 text-dark"></i>
    </div>

    <div class="text-center mb-4">
        <h4 class="fw-bold mb-2"><?php echo e(__('Masuk ke akun Anda')); ?></h4>
        <p class="text-muted small mb-0"><?php echo e(__('Masukkan alamat email dan kata sandi Anda untuk mengakses akun Anda')); ?></p>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger py-2 text-sm mb-3 border-0 bg-danger-subtle text-danger rounded-3">
            <i class="bi bi-exclamation-circle me-1"></i> <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('login')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <i class="bi bi-envelope input-icon"></i>
            <input type="email" 
                   class="form-control-custom" 
                   id="email" 
                   name="email" 
                   placeholder="Email" 
                   value="<?php echo e(old('email')); ?>" 
                   required 
                   autofocus>
        </div>

        <div class="form-group">
            <i class="bi bi-lock input-icon"></i>
            <input type="password" 
                   class="form-control-custom" 
                   id="password" 
                   name="password" 
                   placeholder="Password" 
                   required>
            
            <button type="button" class="password-toggle" onclick="togglePassword()">
                <i class="bi bi-eye-slash" id="toggleIcon"></i>
            </button>
        </div>

        <button type="submit" class="btn-login mt-2">
            <?php echo e(__('Masuk')); ?>

        </button>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\koperasi\koperasi_web\resources\views/auth/login.blade.php ENDPATH**/ ?>