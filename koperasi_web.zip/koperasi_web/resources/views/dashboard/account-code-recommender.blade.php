@extends('layouts.app')

@section('page_title', 'Rekomendasi Kode Akun')

@section('content')
<div class="container py-4">

    {{-- STEP INDICATOR --}}
    <div class="steps d-flex justify-content-between mb-4">
        <div class="step-item {{ $step >= 1 ? 'active' : '' }} {{ $step == 1 ? 'current' : '' }}">
            <div class="step-number">1</div><div class="step-title">Unggah File</div>
        </div>
        <div class="step-item {{ $step >= 2 ? 'active' : '' }} {{ $step == 2 ? 'current' : '' }}">
            <div class="step-number">2</div><div class="step-title">Memproses</div>
        </div>
        <div class="step-item {{ $step >= 3 ? 'active' : '' }} {{ $step == 3 ? 'current' : '' }}">
            <div class="step-number">3</div><div class="step-title">Hasil</div>
        </div>
    </div>

    {{-- STEP 1: UPLOAD --}}
    @if($step == 1)
        <form action="{{ route('account-code-recommender.store') }}" method="POST" enctype="multipart/form-data">
            @csrf 
            <div class="card shadow-sm border-0">
                <div class="card-body text-center py-5" id="dropZone">
                    <i class="bi bi-cloud-arrow-up fs-1 text-secondary mb-3"></i>
                    <p class="mb-1">Letakkan dokumen di sini, atau <a href="#" id="browseLink" class="text-decoration-none fw-bold">pilih file</a></p>
                    <small class="text-muted d-block mb-3">JPG, PNG (Maks 10MB)</small>
                    
                    <input type="file" name="document" id="fileInput" class="d-none" accept=".jpg,.jpeg,.png">
                    
                    {{-- Area Nama File (Fixed Height agar tidak geser) --}}
                    <div style="height: 24px;" class="mt-2">
                        <p id="fileName" class="fw-bold mb-0 text-primary small text-truncate"></p>
                    </div>
                    
                    <button type="submit" class="btn btn-primary mt-2 px-4" id="uploadButton" disabled>Unggah Dokumen</button>
                </div>
            </div>
        </form>
    @endif

    {{-- STEP 2: PROCESS --}}
    @if($step == 2)
        <div class="card shadow-sm border-0">
            <div class="card-body text-center py-5">
                <div class="spinner-border text-primary mb-3" role="status"></div>
                <h5 class="fw-bold">Sedang Menganalisis...</h5>
                <p class="text-muted">AI sedang membaca data dari gambar Anda.</p>
            </div>
        </div>
    @endif

    {{-- STEP 3: HASIL & VERIFIKASI (LAYOUT 2 KOLOM) --}}
    @if($step == 3)
        <form action="{{ route('recommender.save') }}" method="POST" id="saveForm">
            @csrf
            <div class="row">
                {{-- KIRI: GAMBAR SUMBER --}}
                <div class="col-lg-5 mb-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white py-3 fw-bold">Bukti Transaksi</div>
                        <div class="card-body bg-light text-center d-flex align-items-center justify-content-center p-2">
                            <img src="{{ $image_url }}" class="img-fluid rounded shadow-sm" style="max-height: 500px;" alt="Preview Struk">
                        </div>
                    </div>
                </div>

                {{-- KANAN: FORM INPUT HITL --}}
                <div class="col-lg-7">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white py-3 fw-bold text-primary">Rekomendasi Jurnal Entri</div>
                        <div class="card-body p-4">
                            
                            {{-- 1. INFORMASI DASAR (Total dihapus dari sini) --}}
                            <div class="row g-3 mb-4">
                                <div class="col-md-6">
                                    <label class="form-label small text-muted text-uppercase fw-bold">Tanggal</label>
                                    <input type="date" class="form-control" name="tanggal" 
                                           value="{{ $result['tanggal_transaksi'] ?? date('Y-m-d') }}">
                                </div>
                                {{-- Input Total DIHAPUS dari sini --}}
                                
                                <div class="col-md-6">
                                    <label class="form-label small text-muted text-uppercase fw-bold">Jenis Bukti</label>
                                    <select class="form-select" name="jenis_bukti">
                                        <option value="BKK" selected>BKK (Kas Keluar)</option>
                                        <option value="BKM">BKM (Kas Masuk)</option>
                                        <option value="BM">BM (Memorial)</option>
                                        <option value="Pembelian">Pembelian</option>
                                        <option value="Penjualan">Penjualan</option>
                                    </select>
                                </div>
                            </div>

                            <hr>

                            {{-- 2. ENTRI JURNAL --}}
                            <h6 class="fw-bold mb-3 small text-uppercase text-muted">Entri Jurnal</h6>
                            <div class="bg-light p-3 rounded border">
                                <div class="bg-light p-3 rounded border">
                                {{-- Header --}}
                                <div class="row g-2 mb-2 text-muted small fw-bold">
                                    <div class="col-6">Akun</div>
                                    <div class="col-3 text-end">Debit</div>
                                    <div class="col-3 text-end">Kredit</div>
                                </div>

                                {{-- BARIS 1: DEBIT (Bisa Edit) --}}
                                <div class="row g-2 mb-2 align-items-center">
                                    <div class="col-6">
                                        <select class="form-select form-select-sm" name="selected_account" id="accountDebit">
                                            <option value="">-- Pilih Akun --</option>
                                            @foreach($groupedAccounts as $groupName => $accounts)
                                                <optgroup label="{{ $groupName }}">
                                                    @foreach($accounts as $acc)
                                                        <option value="{{ $acc->code }}">{{ $acc->code }} - {{ $acc->name }}</option>
                                                    @endforeach
                                                </optgroup>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-3">
                                        {{-- HAPUS readonly --}}
                                        <input type="number" class="form-control form-control-sm text-end nominal-input" 
                                               name="debit_amount" id="debitInput" 
                                               value="{{ $result['nominal_total'] ?? 0 }}">
                                    </div>
                                    <div class="col-3">
                                        {{-- Kredit 0 tapi bisa diedit --}}
                                        <input type="number" class="form-control form-control-sm text-end nominal-input" 
                                               name="credit_amount_1" value="0">
                                    </div>
                                </div>

                                {{-- FOOTER TOTAL (Kalkulasi Realtime) --}}
                                <div class="row g-2 align-items-center fw-bold">
                                    <div class="col-6 text-end small text-uppercase pe-3">Total Transaksi</div>
                                    <div class="col-3">
                                        <input type="text" class="form-control form-control-sm text-end bg-secondary-subtle fw-bold" 
                                               id="totalDebitDisplay" value="0" readonly>
                                    </div>
                                    <div class="col-3">
                                        <input type="text" class="form-control form-control-sm text-end bg-secondary-subtle fw-bold" 
                                               id="totalCreditDisplay" value="0" readonly>
                                    </div>
                                    {{-- Hidden Input untuk kirim ke Controller --}}
                                    <input type="hidden" name="nominal_total" id="hiddenNominalTotal" value="0">
                                </div>

                            </div>

                            {{-- Indikator Balance Dinamis --}}
                            <div id="balanceAlert" class="alert d-flex align-items-center py-2 mt-3 mb-0 border-0 small">
                                <i class="bi me-2" id="balanceIcon"></i>
                                <strong id="balanceText">Menghitung...</strong>
                            </div>

                        </div>
                        <div class="card-footer bg-white text-end py-3 border-top-0">
                            <a href="{{ route('account-code-recommender.show', 1) }}" class="btn btn-light me-2">Batal</a>
                            <button type="button" class="btn btn-primary px-4" id="saveButton">Simpan Transaksi</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    @endif

</div>

@push('styles')
<style>
    .drop-zone-over { border: 2px dashed #0d6efd !important; background-color: #f0f5ff; }
    .steps { margin-bottom: 2rem; position: relative; }
    .steps::before { content: ""; position: absolute; top: 15px; left: 0; width: 100%; height: 2px; background: #e9ecef; z-index: -1; }
    .step-item { background: #f8fafc; padding: 0 10px; text-align: center; }
    .step-number { width: 30px; height: 30px; line-height: 30px; border-radius: 50%; background: #e9ecef; color: #6c757d; font-weight: bold; margin: 0 auto; }
    .step-item.active .step-number { background: #0d6efd; color: white; }
    .step-title { font-size: 0.8rem; margin-top: 5px; color: #6c757d; }
    .step-item.active .step-title { color: #0d6efd; font-weight: bold; }
</style>
@endpush

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', () => {
        // --- 1. HANDLE ERROR DARI BACKEND (TOAST) ---
        @if ($errors->any())
            @foreach ($errors->all() as $error)
                if (typeof showToast === 'function') showToast("{{ $error }}", 'error');
                else alert("{{ $error }}");
            @endforeach
        @endif

        // --- 2. INISIALISASI BERDASARKAN STEP ---
        const currentStep = {{ $step ?? 1 }};
        if(currentStep === 1) setupFileUpload();
        if(currentStep === 2) processAI();
        if(currentStep === 3) setupFormLogic();
    });

    // --- FUNGSI STEP 1: UPLOAD ---
    function setupFileUpload() {
        const fileInput = document.getElementById('fileInput');
        const browseLink = document.getElementById('browseLink');
        const fileNameDisplay = document.getElementById('fileName');
        const uploadButton = document.getElementById('uploadButton');
        const dropZone = document.getElementById('dropZone');

        if (!dropZone) return;

        browseLink.addEventListener('click', (e) => { e.preventDefault(); fileInput.click(); });
        
        fileInput.addEventListener('change', () => {
            if (fileInput.files.length > 0) {
                const file = fileInput.files[0];
                // Validasi Frontend
                const validTypes = ['image/jpeg', 'image/png', 'image/jpg'];
                if (!validTypes.includes(file.type)) {
                    if(typeof showToast === 'function') showToast("Format file salah. Gunakan JPG/PNG.", 'error');
                    else alert("Format salah.");
                    fileInput.value = ''; return;
                }
                if (file.size > 10 * 1024 * 1024) {
                    if(typeof showToast === 'function') showToast("Ukuran maks 10MB.", 'error');
                    else alert("File terlalu besar.");
                    fileInput.value = ''; return;
                }
                fileNameDisplay.textContent = "File: " + file.name;
                uploadButton.disabled = false;
            }
        });

        // Drag & Drop Effect
        ['dragenter', 'dragover'].forEach(e => dropZone.addEventListener(e, (ev) => { ev.preventDefault(); dropZone.classList.add('drop-zone-over'); }));
        ['dragleave', 'drop'].forEach(e => dropZone.addEventListener(e, (ev) => { ev.preventDefault(); dropZone.classList.remove('drop-zone-over'); }));
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            fileInput.files = e.dataTransfer.files;
            fileInput.dispatchEvent(new Event('change'));
        });
    }

    // --- FUNGSI STEP 2: PROSES AI ---
    function processAI() {
        fetch('{{ route("recommender.process") }}', {
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Accept': 'application/json' }
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.href = '{{ route("account-code-recommender.show", ["step" => 3]) }}';
            } else { 
                if(typeof showToast === 'function') showToast(data.message || "Gagal memproses.", 'error');
                else alert(data.message);
                setTimeout(() => window.location.href = '{{ route("account-code-recommender.show", 1) }}', 2000);
            }
        })
        .catch(() => {
            if(typeof showToast === 'function') showToast("Server Error.", 'error');
            setTimeout(() => window.location.href = '{{ route("account-code-recommender.show", 1) }}', 2000);
        });
    }

    // --- FUNGSI STEP 3: LOGIKA FORM INPUT (HITL) ---
    function setupFormLogic() {
        // 1. Auto-Select Akun (Sama seperti sebelumnya)
        const aiCode = "{{ $result['rekomendasi_akun_transaksi'][0]['kode_akun'] ?? '' }}";
        const debitSelect = document.getElementById('accountDebit');
        if (aiCode && debitSelect) {
            // ... (kode pencarian opsi sama seperti sebelumnya) ...
             let found = false;
            const optgroups = debitSelect.getElementsByTagName('optgroup');
            for (let group of optgroups) {
                for (let option of group.children) {
                    if (option.value == aiCode) {
                        debitSelect.value = aiCode;
                        found = true;
                        break;
                    }
                }
                if(found) break;
            }
        }

        // 2. LOGIKA BARU: Kalkulasi Manual & Cek Balance
        const inputs = document.querySelectorAll('.nominal-input');
        const totalDebitEl = document.getElementById('totalDebitDisplay');
        const totalCreditEl = document.getElementById('totalCreditDisplay');
        const hiddenTotal = document.getElementById('hiddenNominalTotal');
        const balanceAlert = document.getElementById('balanceAlert');
        const balanceIcon = document.getElementById('balanceIcon');
        const balanceText = document.getElementById('balanceText');
        const saveBtn = document.getElementById('saveButton');

        function calculateBalance() {
            let sumDebit = 0;
            let sumCredit = 0;

            // Loop semua input
            inputs.forEach(input => {
                const val = parseFloat(input.value) || 0;
                // Cek apakah input ini kolom Debit atau Kredit berdasarkan posisi parent/index
                // Cara simpel: Input ke-2 di row adalah Debit, Input ke-3 adalah Kredit
                const parentRow = input.closest('.row');
                const index = Array.from(parentRow.children).indexOf(input.parentElement);
                
                if (index === 1) sumDebit += val; // Kolom tengah (Debit)
                if (index === 2) sumCredit += val; // Kolom kanan (Kredit)
            });

            totalDebitEl.value = sumDebit;
            totalCreditEl.value = sumCredit;
            hiddenTotal.value = sumDebit; // Asumsi total transaksi ambil dari sisi debit

            // Cek Balance
            if (sumDebit === sumCredit && sumDebit > 0) {
                balanceAlert.className = "alert alert-success d-flex align-items-center py-2 mt-3 mb-0 border-0 bg-success-subtle text-success small";
                balanceIcon.className = "bi bi-check-circle-fill me-2";
                balanceText.textContent = "Debit dan Kredit seimbang.";
                saveBtn.disabled = false;
            } else {
                balanceAlert.className = "alert alert-danger d-flex align-items-center py-2 mt-3 mb-0 border-0 bg-danger-subtle text-danger small";
                balanceIcon.className = "bi bi-exclamation-triangle-fill me-2";
                balanceText.textContent = `Tidak Seimbang! Selisih: ${Math.abs(sumDebit - sumCredit)}`;
                saveBtn.disabled = true; // Cegah simpan jika tidak balance
            }
        }

        // Pasang Event Listener ke semua input nominal
        inputs.forEach(input => {
            input.addEventListener('input', calculateBalance);
        });

        // Jalankan sekali saat load
        calculateBalance();

        // 3. Simpan Data (Sama seperti sebelumnya)
        if(saveBtn) {
            saveBtn.addEventListener('click', () => {
                // ... (kode ajax simpan sama) ...
                 saveBtn.disabled = true;
                saveBtn.textContent = 'Menyimpan...';
                
                const formData = new FormData(document.getElementById('saveForm'));
                fetch('{{ route("recommender.save") }}', {
                    method: 'POST', body: formData,
                    headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Accept': 'application/json' }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success') {
                        notify("Transaksi Berhasil Disimpan!", 'success');
                        setTimeout(() => window.location.href = '{{ route("account-code-recommender.show", 1) }}', 1000);
                    } else {
                        notify(data.message || 'Gagal menyimpan.', 'error');
                        saveBtn.disabled = false;
                        saveBtn.textContent = 'Simpan Transaksi';
                    }
                })
                .catch(() => {
                    notify("Terjadi kesalahan pada server.", 'error');
                    saveBtn.disabled = false;
                    saveBtn.textContent = 'Simpan Transaksi';
                });
            });
        }
    }
</script>
@endpush
@endsection